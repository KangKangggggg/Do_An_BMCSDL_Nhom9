-- =============================================
-- 2. TẠO CÁC BẢNG CHÍNH
-- =============================================

-- Bảng Phòng ban
CREATE TABLE HR_APP.DEPARTMENT (
    DEPARTMENTID    NUMBER PRIMARY KEY,
    DEPARTMENTNAME  VARCHAR2(50) NOT NULL
);

-- Bảng APP_USER (quản lý tài khoản)
CREATE TABLE HR_APP.APP_USER (
    USERNAME       VARCHAR2(30) PRIMARY KEY,
    PASSWORD       VARCHAR2(100) NOT NULL,
    FULLNAME       VARCHAR2(100),
    DEPARTMENTID   NUMBER,
    ROLE           VARCHAR2(20) DEFAULT 'NHANVIEN',
    IS_ACTIVE      NUMBER(1,0) DEFAULT 1,
    CREATED_DATE   DATE DEFAULT SYSDATE,
    CONSTRAINT fk_appuser_dept FOREIGN KEY (DEPARTMENTID) 
        REFERENCES HR_APP.DEPARTMENT(DEPARTMENTID)
);

-- Bảng EMPLOYEE (thông tin nhân viên)
CREATE TABLE HR_APP.EMPLOYEE (
    EMPLOYEEID     NUMBER PRIMARY KEY,
    FULLNAME       VARCHAR2(100) NOT NULL,
    BIRTHDATE      DATE,
    EMAIL          VARCHAR2(100),
    DEPARTMENTID   NUMBER,
    POSITION       VARCHAR2(50),
    SALARY         NUMBER(12,2),
    TAXCODE        VARCHAR2(20),
    ORACLEUSER     VARCHAR2(30),
    CONSTRAINT fk_employee_dept FOREIGN KEY (DEPARTMENTID) 
        REFERENCES HR_APP.DEPARTMENT(DEPARTMENTID),
    CONSTRAINT fk_employee_user FOREIGN KEY (ORACLEUSER) 
        REFERENCES HR_APP.APP_USER(USERNAME)
);

-- =============================================
-- 3. TẠO VIEW CHO NHÂN VIÊN THƯỜNG
-- =============================================
CREATE OR REPLACE VIEW HR_APP.VW_EMPLOYEE_NHANVIEN AS
SELECT 
    EMPLOYEEID,
    FULLNAME,
    BIRTHDATE,
    EMAIL,
    DEPARTMENTID,
    POSITION,
    ORACLEUSER
FROM HR_APP.EMPLOYEE;

-- =============================================
-- 4. TẠO ROLE VÀ GÁN QUYỀN
-- =============================================
CREATE ROLE ROLE_NHANVIEN;

GRANT CONNECT, CREATE SESSION TO ROLE_NHANVIEN;
GRANT SELECT ON HR_APP.VW_EMPLOYEE_NHANVIEN TO ROLE_NHANVIEN;
GRANT SELECT ON HR_APP.DEPARTMENT TO ROLE_NHANVIEN;

-- =============================================
-- 5. TẠO 50 USER VÀ GÁN ROLE
-- =============================================
BEGIN
    FOR i IN 1..50 LOOP
        DECLARE
            v_username VARCHAR2(30) := 'EMP' || LPAD(i, 3, '0');
            v_dept_id  NUMBER := ((i-1) / 10) + 1;
        BEGIN
            -- Tạo Oracle User
            EXECUTE IMMEDIATE 'CREATE USER ' || v_username || ' IDENTIFIED BY 123';
            
            -- Gán Role
            EXECUTE IMMEDIATE 'GRANT ROLE_NHANVIEN TO ' || v_username;
            
            -- Thêm vào bảng APP_USER
            INSERT INTO HR_APP.APP_USER (USERNAME, PASSWORD, FULLNAME, DEPARTMENTID, ROLE)
            VALUES (v_username, '123', 'Nhân viên ' || v_username, v_dept_id, 'NHANVIEN');
        END;
    END LOOP;
    COMMIT;
END;
/

-- =============================================
-- 6. KIỂM TRA (có thể chạy để verify)
-- =============================================
SELECT 'DEPARTMENT' AS TABLE_NAME, COUNT(*) AS ROW_COUNT FROM HR_APP.DEPARTMENT;
SELECT 'APP_USER' AS TABLE_NAME, COUNT(*) AS ROW_COUNT FROM HR_APP.APP_USER;
SELECT 'EMPLOYEE' AS TABLE_NAME, COUNT(*) AS ROW_COUNT FROM HR_APP.EMPLOYEE;
SELECT 'VW_EMPLOYEE_NHANVIEN' AS VIEW_NAME, COUNT(*) AS ROW_COUNT FROM HR_APP.VW_EMPLOYEE_NHANVIEN;