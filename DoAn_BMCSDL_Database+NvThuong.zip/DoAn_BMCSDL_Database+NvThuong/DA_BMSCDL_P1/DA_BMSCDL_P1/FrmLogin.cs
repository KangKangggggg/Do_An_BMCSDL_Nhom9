﻿using DA_BMCSDL_P1;
using DA_BMSCDL_P1.Database;
using Oracle.ManagedDataAccess.Client;
namespace DA_BMSCDL_P1
{
    public partial class FrmLogin : Form
    {
        private OracleConnection conn;

        public FrmLogin()
        {
            InitializeComponent();
        }

        private void btnLogin_Click(object sender, EventArgs e)
        {
            string username = txtUsername.Text.Trim().ToUpper();
            string password = txtPassword.Text;

            if (string.IsNullOrWhiteSpace(username) || string.IsNullOrWhiteSpace(password))
            {
                MessageBox.Show("Vui lòng nhập đầy đủ tên đăng nhập và mật khẩu!",
                                "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            DbConnection db = new DbConnection();
            OracleConnection conn = db.GetConnection(username, password);

            try
            {
                conn.Open();
                Program.CurrentConnection = conn;
                MessageBox.Show("Đăng nhập thành công!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);

                string currentFullName = "";
                string currentDepartment = "";

                string sqlInfo = @"
            SELECT e.FullName, d.DepartmentName 
            FROM HR_APP.Employee e
            LEFT JOIN HR_APP.Department d ON e.DepartmentID = d.DepartmentID
            WHERE e.OracleUser = :username";

                using (OracleCommand cmd = new OracleCommand(sqlInfo, conn))
                {
                    cmd.Parameters.Add(":username", OracleDbType.Varchar2).Value = username;

                    using (OracleDataReader rd = cmd.ExecuteReader())
                    {
                        if (rd.Read())
                        {
                            currentFullName = rd["FullName"].ToString();
                            currentDepartment = rd["DepartmentName"] != DBNull.Value
                                                ? rd["DepartmentName"].ToString()
                                                : "Không xác định";
                        }
                        else
                        {
                            currentFullName = username;
                            currentDepartment = "Không xác định";
                        }
                    }
                }
                FrmEmployee frm = new FrmEmployee(conn, currentFullName, currentDepartment);
                frm.Show();
                this.Hide();
            }
            catch (OracleException ex)
            {
                MessageBox.Show("Đăng nhập thất bại!\n\n" + ex.Message,
                                "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
                conn.Dispose();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi hệ thống:\n" + ex.Message, "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnQuit_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show(
                "Bạn có chắc chắn muốn thoát không?",
                "Xác nhận",
                MessageBoxButtons.YesNo,
                MessageBoxIcon.Question) == DialogResult.Yes)
            {
                Application.Exit();
            }

        }

        private void btnForgotPassword_Click(object sender, EventArgs e)
        {
            string username = txtUsername.Text.Trim().ToUpper();
            if (string.IsNullOrWhiteSpace(username))
            {
                MessageBox.Show("Vui lòng nhập tên đăng nhập trước khi đổi mật khẩu!",
                                "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            FrmChangePassword frm = new FrmChangePassword(username);
            frm.ShowDialog();
        }
    }
}
