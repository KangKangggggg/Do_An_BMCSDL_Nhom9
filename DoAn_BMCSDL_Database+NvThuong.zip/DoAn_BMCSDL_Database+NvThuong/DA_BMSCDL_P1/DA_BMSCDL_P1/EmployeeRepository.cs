﻿using Oracle.ManagedDataAccess.Client;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DA_BMCSDL_P1
{
    public class EmployeeRepository
    {
        private readonly OracleConnection _conn;

        public EmployeeRepository(OracleConnection conn)
        {
            _conn = conn;
        }

        public DataTable GetEmployeesByCurrentUser()
        {
            string sql = @"
                SELECT 
                    EmployeeID,
                    FullName,
                    BirthDate,
                    Email,
                    Position
                FROM HR_APP.VW_EMPLOYEE_NHANVIEN
                WHERE DepartmentID = (
                    SELECT DepartmentID
                    FROM HR_APP.Employee
                    WHERE OracleUser = USER
                )
                ORDER BY EmployeeID";

            using (OracleDataAdapter da = new OracleDataAdapter(sql, _conn))
            {
                DataTable dt = new DataTable();
                da.Fill(dt);
                return dt;
            }
        }

        public DataTable SearchEmployees(string maNV, string hoTen, string email, string chucVu,
                                       CheckedListBox.CheckedItemCollection checkedItems)
        {
            string baseSql = @"
                SELECT 
                    EmployeeID,
                    FullName,
                    BirthDate,
                    Email,
                    Position
                FROM HR_APP.VW_EMPLOYEE_NHANVIEN
                WHERE DepartmentID = (
                    SELECT DepartmentID
                    FROM HR_APP.Employee
                    WHERE OracleUser = USER
                )";

            using (OracleCommand cmd = new OracleCommand())
            {
                cmd.Connection = _conn;
                bool hasCondition = false;

                foreach (string item in checkedItems)
                {
                    if (item == "Mã nhân viên" && !string.IsNullOrWhiteSpace(maNV))
                    {
                        baseSql += " AND EmployeeID = :id";
                        cmd.Parameters.Add(":id", OracleDbType.Int32).Value = Convert.ToInt32(maNV);
                        hasCondition = true;
                    }
                    else if (item == "Họ tên" && !string.IsNullOrWhiteSpace(hoTen))
                    {
                        baseSql += " AND UPPER(FullName) LIKE UPPER(:name)";
                        cmd.Parameters.Add(":name", OracleDbType.Varchar2).Value = "%" + hoTen.Trim() + "%";
                        hasCondition = true;
                    }
                    else if (item == "Email" && !string.IsNullOrWhiteSpace(email))
                    {
                        baseSql += " AND UPPER(Email) LIKE UPPER(:email)";
                        cmd.Parameters.Add(":email", OracleDbType.Varchar2).Value = "%" + email.Trim() + "%";
                        hasCondition = true;
                    }
                    else if (item == "Chức vụ" && !string.IsNullOrWhiteSpace(chucVu))
                    {
                        baseSql += " AND UPPER(Position) LIKE UPPER(:pos)";
                        cmd.Parameters.Add(":pos", OracleDbType.Varchar2).Value = "%" + chucVu.Trim() + "%";
                        hasCondition = true;
                    }
                }

                baseSql += " ORDER BY EmployeeID";
                cmd.CommandText = baseSql;

                using (OracleDataAdapter da = new OracleDataAdapter(cmd))
                {
                    DataTable dt = new DataTable();
                    da.Fill(dt);
                    return dt;
                }
            }
        }
    }
}
