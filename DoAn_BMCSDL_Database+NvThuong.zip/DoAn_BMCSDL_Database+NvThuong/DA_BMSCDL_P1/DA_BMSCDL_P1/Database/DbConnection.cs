﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Oracle.ManagedDataAccess.Client;
using System.Data;

namespace DA_BMSCDL_P1.Database
{
    public class DbConnection
    {
        public OracleConnection GetConnection(string username, string password)
        {
            string connectionString =
                $"User Id={username};" +
                $"Password={password};" +
                "Data Source=(DESCRIPTION=" +
                "(ADDRESS=(PROTOCOL=TCP)(HOST=localhost)(PORT=1521))" +
                "(CONNECT_DATA=(SERVICE_NAME=FREEPDB1)));";

            return new OracleConnection(connectionString);
        }
    }
}
