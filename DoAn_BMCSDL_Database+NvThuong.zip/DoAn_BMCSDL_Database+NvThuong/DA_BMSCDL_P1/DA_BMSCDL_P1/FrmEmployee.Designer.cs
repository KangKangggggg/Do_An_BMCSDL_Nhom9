﻿namespace DA_BMCSDL_P1
{
    partial class FrmEmployee
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            label4 = new Label();
            btnTimKiem = new Button();
            clbTimKiem = new CheckedListBox();
            dgvEmployee = new DataGridView();
            btnLogout = new Button();
            txtMaNV = new TextBox();
            txtHoTen = new TextBox();
            txtEmail = new TextBox();
            txtChucVu = new TextBox();
            lblXinChao = new Label();
            lblPhongBan = new Label();
            ((System.ComponentModel.ISupportInitialize)dgvEmployee).BeginInit();
            SuspendLayout();
            // 
            // label1
            // 
            label1.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.Location = new Point(454, 23);
            label1.Name = "label1";
            label1.Size = new Size(226, 34);
            label1.TabIndex = 0;
            label1.Text = "QUẢN LÝ NHÂN VIÊN";
            label1.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Segoe UI Semibold", 10.2F, FontStyle.Bold);
            label2.Location = new Point(59, 98);
            label2.Name = "label2";
            label2.Size = new Size(81, 23);
            label2.TabIndex = 1;
            label2.Text = "Xin chào:";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Segoe UI Semibold", 10.2F, FontStyle.Bold);
            label3.Location = new Point(59, 201);
            label3.Name = "label3";
            label3.Size = new Size(98, 23);
            label3.TabIndex = 3;
            label3.Text = "Phòng ban:";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Segoe UI Semibold", 10.2F, FontStyle.Bold);
            label4.Location = new Point(366, 98);
            label4.Name = "label4";
            label4.Size = new Size(84, 23);
            label4.TabIndex = 5;
            label4.Text = "Tìm kiếm:";
            // 
            // btnTimKiem
            // 
            btnTimKiem.Font = new Font("Segoe UI Semibold", 10.2F, FontStyle.Bold);
            btnTimKiem.Location = new Point(499, 280);
            btnTimKiem.Name = "btnTimKiem";
            btnTimKiem.Size = new Size(114, 29);
            btnTimKiem.TabIndex = 7;
            btnTimKiem.Text = "Tìm";
            btnTimKiem.UseVisualStyleBackColor = true;
            btnTimKiem.Click += btnTimKiem_Click;
            // 
            // clbTimKiem
            // 
            clbTimKiem.Font = new Font("Segoe UI Semibold", 10.2F, FontStyle.Bold);
            clbTimKiem.FormattingEnabled = true;
            clbTimKiem.Items.AddRange(new object[] { "Mã nhân viên", "Họ tên", "Email", "Chức vụ" });
            clbTimKiem.Location = new Point(366, 143);
            clbTimKiem.Name = "clbTimKiem";
            clbTimKiem.Size = new Size(247, 104);
            clbTimKiem.TabIndex = 10;
            // 
            // dgvEmployee
            // 
            dgvEmployee.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgvEmployee.Location = new Point(59, 363);
            dgvEmployee.Name = "dgvEmployee";
            dgvEmployee.RowHeadersWidth = 51;
            dgvEmployee.Size = new Size(888, 338);
            dgvEmployee.TabIndex = 11;
            dgvEmployee.CellContentClick += dgvEmployee_CellContentClick;
            // 
            // btnLogout
            // 
            btnLogout.Font = new Font("Segoe UI Semibold", 10.2F, FontStyle.Bold);
            btnLogout.Location = new Point(1001, 668);
            btnLogout.Name = "btnLogout";
            btnLogout.Size = new Size(133, 33);
            btnLogout.TabIndex = 12;
            btnLogout.Text = "Đăng xuất";
            btnLogout.UseVisualStyleBackColor = true;
            btnLogout.Click += btnLogout_Click;
            // 
            // txtMaNV
            // 
            txtMaNV.Font = new Font("Segoe UI Semibold", 10.2F, FontStyle.Bold);
            txtMaNV.Location = new Point(693, 95);
            txtMaNV.Name = "txtMaNV";
            txtMaNV.Size = new Size(254, 30);
            txtMaNV.TabIndex = 13;
            // 
            // txtHoTen
            // 
            txtHoTen.Font = new Font("Segoe UI Semibold", 10.2F, FontStyle.Bold);
            txtHoTen.Location = new Point(693, 144);
            txtHoTen.Name = "txtHoTen";
            txtHoTen.Size = new Size(254, 30);
            txtHoTen.TabIndex = 14;
            // 
            // txtEmail
            // 
            txtEmail.Font = new Font("Segoe UI Semibold", 10.2F, FontStyle.Bold);
            txtEmail.Location = new Point(693, 194);
            txtEmail.Name = "txtEmail";
            txtEmail.Size = new Size(254, 30);
            txtEmail.TabIndex = 15;
            // 
            // txtChucVu
            // 
            txtChucVu.Font = new Font("Segoe UI Semibold", 10.2F, FontStyle.Bold);
            txtChucVu.Location = new Point(693, 245);
            txtChucVu.Name = "txtChucVu";
            txtChucVu.Size = new Size(254, 30);
            txtChucVu.TabIndex = 16;
            // 
            // lblXinChao
            // 
            lblXinChao.BackColor = SystemColors.Control;
            lblXinChao.Font = new Font("Segoe UI Semibold", 10.2F, FontStyle.Bold);
            lblXinChao.Location = new Point(166, 98);
            lblXinChao.Name = "lblXinChao";
            lblXinChao.Size = new Size(139, 23);
            lblXinChao.TabIndex = 17;
            lblXinChao.Text = "text";
            // 
            // lblPhongBan
            // 
            lblPhongBan.BackColor = SystemColors.Control;
            lblPhongBan.Font = new Font("Segoe UI Semibold", 10.2F, FontStyle.Bold);
            lblPhongBan.Location = new Point(166, 201);
            lblPhongBan.Name = "lblPhongBan";
            lblPhongBan.Size = new Size(139, 23);
            lblPhongBan.TabIndex = 18;
            lblPhongBan.Text = "text";
            // 
            // FrmEmployee
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1182, 753);
            Controls.Add(lblPhongBan);
            Controls.Add(lblXinChao);
            Controls.Add(txtChucVu);
            Controls.Add(txtEmail);
            Controls.Add(txtHoTen);
            Controls.Add(txtMaNV);
            Controls.Add(btnLogout);
            Controls.Add(dgvEmployee);
            Controls.Add(clbTimKiem);
            Controls.Add(btnTimKiem);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Name = "FrmEmployee";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Quản lý nhân viên";
            ((System.ComponentModel.ISupportInitialize)dgvEmployee).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private Label label2;
        private Label label3;
        private Label label4;
        private Button btnTimKiem;
        private CheckedListBox clbTimKiem;
        private DataGridView dgvEmployee;
        private Button btnLogout;
        private TextBox txtMaNV;
        private TextBox txtHoTen;
        private TextBox txtEmail;
        private TextBox txtChucVu;
        private Label lblXinChao;
        private Label lblPhongBan;
    }
}