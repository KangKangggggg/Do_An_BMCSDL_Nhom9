﻿using DA_BMSCDL_P1;
using DA_BMSCDL_P1.Database;
using Oracle.ManagedDataAccess.Client;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace DA_BMCSDL_P1
{
    public partial class FrmChangePassword : Form
    {
        private string currentUsername;

        public FrmChangePassword(string username)
        {
            InitializeComponent();
            currentUsername = username;
            this.Load += FrmChangePassword_Load;
        }

        private void FrmChangePassword_Load(object sender, EventArgs e)
        {
            lblUsername.Text = "Đang đổi mật khẩu cho: " + currentUsername;
            txtNewPassword.UseSystemPasswordChar = true;
            txtConfirmPassword.UseSystemPasswordChar = true;
        }


        private void btnCancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void lblUsername_Click(object sender, EventArgs e)
        {

        }

        private void btnCancel_Click_1(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnChangePassword_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtCurrentPassword.Text) ||
                string.IsNullOrWhiteSpace(txtNewPassword.Text) ||
                string.IsNullOrWhiteSpace(txtConfirmPassword.Text))
            {
                MessageBox.Show("Vui lòng nhập đầy đủ thông tin!",
                                "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (txtNewPassword.Text != txtConfirmPassword.Text)
            {
                MessageBox.Show("Mật khẩu mới và xác nhận không khớp!",
                                "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            if (txtNewPassword.Text == txtCurrentPassword.Text)
            {
                MessageBox.Show("Mật khẩu mới phải khác mật khẩu hiện tại!",
                                "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            OracleConnection tempConn = null;

            try
            {
                DbConnection db = new DbConnection();
                tempConn = db.GetConnection(currentUsername, txtCurrentPassword.Text.Trim());
                tempConn.Open();

                string sql = "BEGIN HR_APP.CHANGE_OWN_PASSWORD(:newpass); END;";

                using (OracleCommand cmd = new OracleCommand(sql, tempConn))
                {
                    cmd.Parameters.Add(":newpass", OracleDbType.Varchar2).Value = txtNewPassword.Text.Trim();
                    cmd.ExecuteNonQuery();
                }

                MessageBox.Show("Đổi mật khẩu thành công!\n\nVui lòng đăng nhập lại với mật khẩu mới.",
                                "Thành công", MessageBoxButtons.OK, MessageBoxIcon.Information);

                this.DialogResult = DialogResult.OK; 
                this.Close();
            }
            catch (OracleException ex)
            {
                MessageBox.Show("Đổi mật khẩu thất bại!\n\n" + ex.Message,
                                "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi hệ thống:\n" + ex.Message,
                                "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                if (tempConn != null)
                {
                    if (tempConn.State == System.Data.ConnectionState.Open)
                        tempConn.Close();
                    tempConn.Dispose();
                }
            }
        }
    }
}
