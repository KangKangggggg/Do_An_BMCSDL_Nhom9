﻿using DA_BMSCDL_P1;
using Oracle.ManagedDataAccess.Client;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DA_BMCSDL_P1
{
    public partial class FrmEmployee : Form
    {
        private OracleConnection conn;
        private string fullName = "";
        private string departmentName = "";
        private EmployeeRepository _repo;
        public FrmEmployee(OracleConnection connection, string fullName, string departmentName)
        {
            InitializeComponent();
            conn = connection;
            this.fullName = fullName;
            this.departmentName = departmentName;
            _repo = new EmployeeRepository(conn);
            this.Load += FrmEmployee_Load;
        }

        private void FrmEmployee_Load(object sender, EventArgs e)
        {

            LoadCurrentUser();     

            LoadEmployee();

            SetupDataGridView();

            clbTimKiem.Items.Clear();
            clbTimKiem.Items.Add("Mã nhân viên");
            clbTimKiem.Items.Add("Họ tên");
            clbTimKiem.Items.Add("Email");
            clbTimKiem.Items.Add("Chức vụ");
        }

        private void LoadCurrentUser()
        {
            lblXinChao.Text = fullName;
            lblPhongBan.Text = departmentName;
        }

        private void LoadEmployee()
        {
            try
            {
                dgvEmployee.DataSource = _repo.GetEmployeesByCurrentUser();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi LoadEmployee:\n" + ex.Message, "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void SetupDataGridView()
        {
            if (dgvEmployee.Columns.Count == 0) return;

            dgvEmployee.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;

            dgvEmployee.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.None;

            dgvEmployee.Columns["EmployeeID"].Width = 80;
            dgvEmployee.Columns["FullName"].Width = 220;
            dgvEmployee.Columns["BirthDate"].Width = 110;
            dgvEmployee.Columns["Email"].Width = 220;
            dgvEmployee.Columns["Position"].Width = 150;

            dgvEmployee.Columns["EmployeeID"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dgvEmployee.Columns["BirthDate"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dgvEmployee.Columns["Position"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dgvEmployee.AllowUserToOrderColumns = false;
            dgvEmployee.AlternatingRowsDefaultCellStyle.BackColor = Color.FromArgb(240, 240, 255);
            dgvEmployee.DefaultCellStyle.SelectionBackColor = Color.FromArgb(0, 120, 215);
        }

        private void btnLogout_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show(
                "Bạn có chắc chắn muốn đăng xuất không?",
                "Xác nhận",
                MessageBoxButtons.YesNo,
                MessageBoxIcon.Question) == DialogResult.Yes)
            {
                conn.Close();

                FrmLogin frm = new FrmLogin();

                frm.Show();

                this.Close();
            }
        }

        private void btnTimKiem_Click(object sender, EventArgs e)
        {
            try
            {
                dgvEmployee.DataSource = _repo.SearchEmployees(
                    txtMaNV.Text,
                    txtHoTen.Text,
                    txtEmail.Text,
                    txtChucVu.Text,
                    clbTimKiem.CheckedItems
                );
                SetupDataGridView();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi tìm kiếm:\n" + ex.Message, "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void lblXinChao_Click(object sender, EventArgs e)
        {

        }

        private void dgvEmployee_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
