﻿namespace DA_BMCSDL_P1
{
    partial class FrmChangePassword
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            lblUsername = new Label();
            txtNewPassword = new TextBox();
            txtConfirmPassword = new TextBox();
            btnCancel = new Button();
            btnChangePassword = new Button();
            txtCurrentPassword = new TextBox();
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            SuspendLayout();
            // 
            // lblUsername
            // 
            lblUsername.BackColor = SystemColors.Control;
            lblUsername.Font = new Font("Segoe UI Semibold", 10.2F, FontStyle.Bold);
            lblUsername.Location = new Point(242, 22);
            lblUsername.Name = "lblUsername";
            lblUsername.Size = new Size(276, 46);
            lblUsername.TabIndex = 0;
            lblUsername.Text = "text";
            lblUsername.TextAlign = ContentAlignment.MiddleCenter;
            lblUsername.Click += lblUsername_Click;
            // 
            // txtNewPassword
            // 
            txtNewPassword.Font = new Font("Segoe UI Semibold", 10.2F, FontStyle.Bold);
            txtNewPassword.Location = new Point(403, 160);
            txtNewPassword.Name = "txtNewPassword";
            txtNewPassword.PasswordChar = '*';
            txtNewPassword.Size = new Size(210, 30);
            txtNewPassword.TabIndex = 1;
            // 
            // txtConfirmPassword
            // 
            txtConfirmPassword.Font = new Font("Segoe UI Semibold", 10.2F, FontStyle.Bold);
            txtConfirmPassword.Location = new Point(403, 221);
            txtConfirmPassword.Name = "txtConfirmPassword";
            txtConfirmPassword.PasswordChar = '*';
            txtConfirmPassword.Size = new Size(210, 30);
            txtConfirmPassword.TabIndex = 2;
            // 
            // btnCancel
            // 
            btnCancel.Font = new Font("Segoe UI Semibold", 10.2F, FontStyle.Bold);
            btnCancel.Location = new Point(176, 307);
            btnCancel.Name = "btnCancel";
            btnCancel.Size = new Size(154, 39);
            btnCancel.TabIndex = 4;
            btnCancel.Text = "Hủy";
            btnCancel.UseVisualStyleBackColor = true;
            btnCancel.Click += btnCancel_Click_1;
            // 
            // btnChangePassword
            // 
            btnChangePassword.Font = new Font("Segoe UI Semibold", 10.2F, FontStyle.Bold);
            btnChangePassword.Location = new Point(459, 307);
            btnChangePassword.Name = "btnChangePassword";
            btnChangePassword.Size = new Size(154, 39);
            btnChangePassword.TabIndex = 5;
            btnChangePassword.Text = "Đổi mật khẩu";
            btnChangePassword.UseVisualStyleBackColor = true;
            btnChangePassword.Click += btnChangePassword_Click;
            // 
            // txtCurrentPassword
            // 
            txtCurrentPassword.Font = new Font("Segoe UI Semibold", 10.2F, FontStyle.Bold);
            txtCurrentPassword.Location = new Point(403, 100);
            txtCurrentPassword.Name = "txtCurrentPassword";
            txtCurrentPassword.Size = new Size(210, 30);
            txtCurrentPassword.TabIndex = 6;
            // 
            // label1
            // 
            label1.Font = new Font("Segoe UI Semibold", 10.2F, FontStyle.Bold);
            label1.Location = new Point(191, 100);
            label1.Name = "label1";
            label1.Size = new Size(174, 30);
            label1.TabIndex = 7;
            label1.Text = "Nhập mật khẩu cũ:";
            label1.TextAlign = ContentAlignment.MiddleLeft;
            // 
            // label2
            // 
            label2.Font = new Font("Segoe UI Semibold", 10.2F, FontStyle.Bold);
            label2.Location = new Point(191, 160);
            label2.Name = "label2";
            label2.Size = new Size(174, 30);
            label2.TabIndex = 8;
            label2.Text = "Nhập mật khẩu mới:";
            label2.TextAlign = ContentAlignment.MiddleLeft;
            // 
            // label3
            // 
            label3.Font = new Font("Segoe UI Semibold", 10.2F, FontStyle.Bold);
            label3.Location = new Point(191, 220);
            label3.Name = "label3";
            label3.Size = new Size(174, 30);
            label3.TabIndex = 9;
            label3.Text = "Xác nhận mật khẩu:";
            label3.TextAlign = ContentAlignment.MiddleLeft;
            // 
            // FrmChangePassword
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(txtCurrentPassword);
            Controls.Add(btnChangePassword);
            Controls.Add(btnCancel);
            Controls.Add(txtConfirmPassword);
            Controls.Add(txtNewPassword);
            Controls.Add(lblUsername);
            Name = "FrmChangePassword";
            Text = "FrmChangePassword";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label lblUsername;
        private TextBox txtNewPassword;
        private TextBox txtConfirmPassword;
        private Button btnCancel;
        private Button btnChangePassword;
        private TextBox txtCurrentPassword;
        private Label label1;
        private Label label2;
        private Label label3;
    }
}